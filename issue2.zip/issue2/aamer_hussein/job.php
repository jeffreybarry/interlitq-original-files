<html>
<head>
<title>The International Literary Quarterly</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
//-->
</script>
<link href="/estilos.css" rel="stylesheet" type="text/css">
</head>

<body>
<?php include("../../header.php"); ?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="10%" align="right" valign="top"> 
      <?php include("../../issue2/menu_issue2.php"); ?>
      <div align="right"></div></td>
    <td width="90%" valign="top">
<table bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" width="679">
        <!-- fwtable fwsrc="content.png" fwbase="home.gif" fwstyle="Dreamweaver" fwdocid = "742308039" fwnested="0" -->
        <tr> 
          <td><img src="/images/issue_img/spacer.gif" width="10" height="1" border="0" alt=""></td>
          <td><img src="/images/issue_img/spacer.gif" width="192" height="1" border="0" alt=""></td>
          <td><img src="/images/issue_img/spacer.gif" width="17" height="1" border="0" alt=""></td>
          <td><img src="/images/issue_img/spacer.gif" width="205" height="1" border="0" alt=""></td>
          <td valign="top"><img src="/images/issue_img/spacer.gif" width="239" height="1" border="0" alt=""></td>
          <td><img src="/images/issue_img/spacer.gif" width="16" height="1" border="0" alt=""></td>
          <td><img src="/images/issue_img/spacer.gif" width="1" height="1" border="0" alt=""></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td colspan="4"><img src="/images/spacer.gif" alt="" name="home_r1_c2" width="653" height="59" border="0" class="link1"></td>
          <td>&nbsp;</td>
          <td><img src="/images/issue_img/spacer.gif" width="1" height="59" border="0" alt=""></td>
        </tr>
        <tr> 
          <td rowspan="4"><img name="home_r2_c1" src="/images/spacer.gif" width="10" height="391" border="0" alt="Click to enlarge picture" title="Click to enlarge picture"></td>
          <td rowspan="2" valign="top"><a href="javascript:;" onMouseUp="MM_openBrWindow('/issue2/aamer_hussein/artwork.html','','width=329,height=464')"><img src="art_small.jpg" alt="Click to enlarge picture." name="home_r2_c2" width="192" height="242" border="0"></a></td>
          <td rowspan="2"><img name="home_r2_c3" src="/images/spacer.gif" width="17" height="242" border="0" alt=""></td>
          <td colspan="2" valign="top" class="titulo2">Singapore Jay <span class="texto2">by 
            <a href="/issue2/aamer_hussein/bio.php" class="link3">Aamer 
            Hussein</a></span></td>
          <td>&nbsp;</td>
          <td><img src="/images/issue_img/spacer.gif" width="1" height="23" border="0" alt=""></td>
        </tr>
        <tr> 
          <td height="219" colspan="2" valign="top" class="texto"> <div align="center"> 
              <p align="center"><br>
                <span class="titulo1">1</span></p>
              <p align="left"><span class="texto2">My first day at Arundales. Masud Sheikh,  elegant as ever with silver hair slicked back and leather patches at tweedy  elbows, is waiting at the doors when my taxi pulls up. I&rsquo;m wearing uniform:  light blue shirt and dark blue blazer, navy pants with pleats and blunt-toed  shoes. I feel like a freak, a leftover from some other decade.&nbsp; <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -Morning, Sir. (I know I have to call  him that, or Mr Masud; no familiarities allowed here.)<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;-You&rsquo;re sloppy, Murad, Mr M tells me, your  shirt collar should be in or out and instead it&lsquo;s half in and half out. Didn&rsquo;t  your father teach you to dress?</span></p>
              <p align="left">&nbsp;</p>
              </div></td>
          <td rowspan="3"><img name="home_r3_c6" src="/images/spacer.gif" width="16" height="368" border="0" alt=""></td>
          <td><img src="/images/issue_img/spacer.gif" width="1" height="219" border="0" alt=""></td>
        </tr>
        <tr> 
          <td colspan="4" rowspan="2" valign="top" class="texto"> 
            <p align="left"><span class="texto2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;It's May. I turned thirteen a month ago, and  I&rsquo;ve been in the hilltop town a week.&nbsp; I  came here with my father, from Bombay by air-conditioned train to Madras, then  a plane to Coimbatore and a car from there, driving up the winding hill roads  through a forest reserve. Looked at monkeys pick lice from each other&rsquo;s fur,  sneezed at the medicinal odour of eucalyptus. <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Even  at home in Karachi, when I was seven or eight, my father would sit me on the  arm of his chair and show me pictures of&nbsp;  his dream houses in faraway places, Hertfordshire, Hampshire, and the  Nilgiris. We're city people, but he&rsquo;s always longed for green places,  waterfalls, lakes, great gardens. And now, eight years later, he&rsquo;s made his  dream come true: rented a villa beside a lake for a year in this Blue Mountain  town. <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; It&rsquo;s  cool even in May, but there are things happening: flower shows, dog shows, boat  races, horse races. I don&rsquo;t even have time to adjust. The matter of school  arose early: I&rsquo;ve been missing classes for six months, so it&rsquo;s urgent that I  start again. My father wants to send me to Lovedale, halfway down the mountain,  where most of the students are the sons and daughters of white planters and  expats who live in big towns hundreds of miles away. But my mother sends a  telegram from Bombay, to tell us I&rsquo;m to start right away at Arundales, the  Theosophist school where Mr Masud is Vice-Principal. <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; I&rsquo;m  to be a boarder, she says.&nbsp; I refuse,  because I hate the idea; I&rsquo;ve never been to an all-male school before, and the  thought of sleeping in a dorm with smelly boys is enough to make me rebel. <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; My  father intervenes. I&rsquo;ll be driven to classes each morning, he promises, and  picked up each evening.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; So.  Here I am, on the porch of my new school.&nbsp;  Ready for my first day. Carrying my blue-and-black-striped tie in my  pocket, because I never wear one. <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; I&rsquo;m  led to a wooden hall, where boys sit in rows on wooden benches, listening to  recorded music.&nbsp; It&rsquo;s Carnatic music,  which I enjoy, though I've only recently heard it for the first time. When  Subbbulakshmi&rsquo;s voice begins its throaty undulations - 'oooo, rangaaa  shaaayeee' - the boys begin to nudge each other and titter, in an obviously  familiar ritual. <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; The  boy sitting next to me leads me to our classroom. His name&rsquo;s Akash; he&rsquo;s  pink-cheeked, pleasant, Punjabi. <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -  You speak Hindi?<br>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  I pause before I answer. <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -  Mmm. <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; (I  still think of the language I know as Urdu. I only left Karachi five months  ago.)<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; At  lunch, Akash takes me to the refectory, where we&rsquo;re fed sticky brown rice that  smells odd, a thin lentil broth speckled with mixed vegetables, steel bowls of  sour curd. The Southern boys are eating with their fingers. I&rsquo;ve never tasted  food like this; Akash can see my surprise. <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -  Good for your soul. He nudges me, winks.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; In  the afternoon, we&rsquo;re in the lab, dissecting frogs, mixing chemicals in vials.  I&rsquo;ve never been in a lab before; I hate it. But there are Art classes, and  English and History which I&rsquo;m good at; Hindi, too, which I&rsquo;ve learnt, in my few  months in the North, to read and write quite well, though I have no Sanskrit  vocabulary.&nbsp;  
            ����������� During the break, Akash tells me he  likes Biggles and Billy Bunter, neither of whom I, who read only grown up  novels, have ever heard of. He offers to lend me one of his books.</span></p>

            <p align="left">&nbsp;</p>
            <p align="center"><span class="titulo1">2</span></p>
            <p align="left"><span class="texto2">I&rsquo;m back at school in August. I&rsquo;m used to the  town by now; to its toy buildings with their red and green imitation Gothic  roofs, its English church and graveyard, its tribal Todas. <br>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;During the holiday I made friends with the Art  teacher, and spent many summer afternoons at her house, trying, unsuccessfully,  to paint. I discovered the library in the centre of town, with its newish  English novels on the ground floor, and its antique volumes upstairs. Enough to  keep me busy, even when it rains, and when it rains in the mountains it&rsquo;s a performance:  shrieking winds, falling branches, grey-black days. At home, we light log  fires.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Akash  no longer shares my desk, or my tuck on tutorial trips to the Botanical  Gardens. All through the summer I&rsquo;d thought I had a friend, but then another  boy&nbsp; told me that he&rsquo;d said he only  looked after me, in those first few days, at someone&rsquo;s behest.&nbsp; Since everyone calls Akash Teacher&rsquo;s Pet, I  can guess who told him to keep an eye on me. Our parting&rsquo;s mutual: maybe he  withdraws because his duty&rsquo;s done, or maybe I do, because I&rsquo;m insulted and  unsure. <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;I'm&nbsp;  afraid to make friends. I&rsquo;m bookish, bad at making overtures; I've been  allowed to give up Physics and Chemistry, but have to do Maths and take  Physical Geography, at which I&rsquo;m just as bad.&nbsp;  The boys I talk to are the two Rameshes. One&rsquo;s a Malayali science genius  and inveterate Biggles and Bunter reader from Singapore. The other, a Gujarati  Jain from Calicut, is jovial and obese. Singapore Ramesh tolerates Fat  Ramesh&nbsp; because he sees him as an  incarnation of Bunter. I don&rsquo;t inhabit Bunterland;&nbsp; I probably attract them only because I&rsquo;m an  outsider, too, and awkward. Many of the boys here come from Africa, Asia, the  Gulf, and my being from Karachi just seems to be a variation on a common theme:  they&rsquo;re too young to care about a three-year-old war, and really I&rsquo;m just like  any other Northern Muslim boy, except for my slightly foreign looks, and what  they call&nbsp; my fancy English accent. 
            ����������� The two Rameshes mean little to me  when I&rsquo;m away from them. But I like my Maths teacher, Miss Rajalakshmi. She's  young, pretty; my second-best friend at school. My best friend&rsquo;s my History  teacher; most of the teachers here are girls, but Mrs Pratap Singh is a plump  older woman from Bhopal, who tells me my essays about Mughal Emperors and  Empresses are as enchanting as fairytales. I should write more, she says, and  publishes something of mine in the school magazine. But when I&rsquo;m home in the  evenings, I never write unless I have to. I read, novels and biographies and  nineteenth-century plays I bring home from the library, and <em>The Illustrated  Weekly</em> which my writer-aunt Annie sends from Bombay. At weekends I go to  every new movie at the only English cinema in town. On dry days I lie in the  sunny grass on my stomach, listening to songs, Hindi film songs on the radio,  Nancy Sinatra and Lee Hazlewood on my portable, battery-operated Italian record  player, singing along with them.</span></p>
            <p align="left">&nbsp;</p>
            <p align="center"><span class="texto2"> </span><span class="titulo1">3</span></p>
            <p align="left"><span class="texto2">November. Often the car breaks down halfway, or  the driver doesn&rsquo;t show up; I have to walk three miles to school, through rain,  slush, sludge. <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; The  last day of term, there&rsquo;s frost. Glinting on grass, luminous on tarmac. There&rsquo;s  a party that night. The girl teachers sing, &lsquo;Somewhere My Love&rsquo;, &lsquo;Those Were  the Days.&rsquo;&nbsp; The lead singer&rsquo;s Saramma,  the Biology teacher. (She&rsquo;s very pretty, played tennis in a hipster <em>sari</em> with <em>palla</em> tucked in at waist throughout the term, and we all stared at  her flat beige belly and her neat navel until Mrs Pratap told her to cover up.) <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; The  lights go off. There&rsquo;s a hush, then a roll of drums and the wail of an electric  guitar. A few notes of the piano, and a rough, high male voice, singing the  first lines of &lsquo;Lucy in the Sky With Diamonds.&rsquo; The group&rsquo;s behind a white  screen; we see their projected shadows. The lead singer&rsquo;s in profile: hawk  nose, curly hair. It&rsquo;s Jayasurya, known to all as Singapore Jay, Ramesh&rsquo;s  maternal uncle. I&rsquo;ve never really noticed him before. I don&rsquo;t really like the  song; even less, the way they sing it.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;(1968 is dying, dying.) <br>
            ����������� We're on our way to Bombay. I'll be  in a big city again;&nbsp; I&rsquo;ll see the sea,  the Arabian sea that comes all the way from Karachi. I&rsquo;ll see my mother after  six months. She&rsquo;s coming back with us to the Blue Mountains, in January.</span></p>
            <p align="left">&nbsp;</p>
            <p align="center"><span class="texto2"> </span><span class="titulo1">4</span></p>
            <p align="left"><span class="texto2">We&rsquo;ve been rehearsing a play since the New Year  began, and I&rsquo;m in it. I&rsquo;d been given a double role, prince and beggar: the  beggar&rsquo;s really the Diamond Prince in disguise. I wasn&rsquo;t the hero, Jay was.  Elviro, the ship&rsquo;s captain, goes off to find a precious pearl for his gipsy  love (played by Saramma).&nbsp; Diamond, in  pauper&rsquo;s disguise, steals it from him. Jay wore boots and breeches; I was in a  gold Grecian tunic.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;I&rsquo;ve grown; at fourteen I'm 5 feet 10, as tall  as a man, nearly as tall as Jay. I&rsquo;m popular, too, with my record collection,  the daring books I read, the polo necks and bell bottoms my mother's brought  for me from a cousin's boutique in Karachi. The best boys in class keep my  company; the Rameshes keep an admiring distance but enjoy my new-found  confidence, as if they&rsquo;d groomed me for success. I walk around with Sirish the  cricketer and Jitendra the tennis player, the class heroes,&nbsp; though I have no particular friend.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; But  since rehearsals began Jay, and three other boys, have been thrown out of  school for breaking rules. They jumped over the walls at night and went into  town: saw films, ate chicken <em>biryani</em>. Dark rumours have it they&rsquo;d been  seen with the town&rsquo;s local slut, the Chinese restaurant owner&rsquo;s wife, smoking  and drinking beer, eating beef and pork. <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; I&rsquo;ve  been offered Jay&rsquo;s role, and his songs. His voice is big and mine's quite  small, but I can carry a tune. <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Now,  after the Easter break, before I have time to fit into his breeches and  boots&nbsp; - he&rsquo;s taller than me, but my  build is bigger, and my feet - Jay's&nbsp;  back.&nbsp; I&rsquo;m scared.&nbsp; Since Rajam, on whom I had a crush last term,  left to get married, I&rsquo;ve been friendly with Saramma; she got me to admit I&rsquo;d  seen the boys in town, at the Regal cinema and at the Three Kings Dosa Palace.&nbsp; She told Mrs Pratap. They were reported,  followed and expelled. But something&rsquo;s made Mr M change his mind; he&rsquo;s summoned  Jay back. Under curfew, I gather. <br>
            ����������� So he&rsquo;s the hero again. And I&rsquo;m the  villain.</span></p>
            <p align="left">&nbsp;</p>
            <p align="center"><span class="texto2"> </span><span class="titulo1">5</span></p>
            <p align="left"><span class="texto2">My second cousin Adeila&rsquo;s come to stay. She&rsquo;s  in trouble because she&rsquo;s been seeing the wrong kind of boy in her hometown,  Sikanderabad. Her mother thinks a month in the Nilgiris will distract her.  Adeila looks and dresses like a Vogue model:&nbsp;  white op-art earrings and huge white-framed glasses, mascarae'd lashes,  geometric Vidal Sassoon haircut, white bell-bottomed pants. Almost as smart as  a Karachi girl.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; She&rsquo;s  forward, too. She knows I look at her. Though I&rsquo;m two years younger, she&rsquo;s  flattered. She&rsquo;s let me hold her hand and taught me to French kiss, but for the  last few days she&rsquo;s been aloof. <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; I  don&rsquo;t know to deal with her. <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; I&rsquo;d  been without female company for more than a year. My mouth dries when Adeila's  around, my groin tightens; when I lie in bed I smell her scent, not the <em>Chant  d&rsquo;Arome</em> she uses but something headier, hair and skin and female otherness.  In my dreams I press my heart against her breasts, taste the insides of her  lips. I&nbsp; wake up, with silvery slime  on&nbsp; my belly or between my thighs. I  sluice myself clean with a whole bucket of cold water I have to fill for myself  from an outside tap; there's no running water and the mornings are cold, even  in summer.<span class="texto2"> </p>
            <p align="left">&nbsp;</p>
            <p align="center"><span class="texto2"> </span><span class="titulo1">6</span></p>
            <p align="left"><span class="texto2">Adeila's on my mind the day there's a fire  alarm and we have to leave the music room. Beyond the tennis court, by the  well, I find myself looking straight into Jay's eyes. I flinch.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -  How&rsquo;s it going, man.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -  Oh, you know. And how about you?<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -  You were really good today. When you asked me to forgive you&hellip;<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -  Oh, I had something else on my mind&hellip;<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -  Like?<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;- Girls. A girl.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; I  find myself telling him about Adeila.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -  Let&rsquo;s go up to the playing field, he says.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; (Later  I realize he noticed others, staring at us.)</span></p>
            <p align="left">&nbsp;</p>
            <p align="center"><span class="texto2"> </span><span class="titulo1">7</span></p>
            <p align="left"><span class="texto2">This was it. A one-off, an accident. He won&rsquo;t  bother to speak to me again. And I&rsquo;ll be off the hook, won&rsquo;t have to tell him  anything about the part I played in his expulsion. <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; I&rsquo;m  staying late at school today, for rehearsals. After classes, I go to the  library to kill the tense half-hour before we start. His hand on my shoulder.  He&rsquo;s behind me; I feel his breath on my ear.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -We&rsquo;re  running late. Come on.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; What  do we talk about? <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Singapore,  Karachi, our plans for tomorrow, the sea.</span></p>
            <p align="left">&nbsp;</p>
            <p align="center"><span class="texto2"> </span><span class="titulo1">8</span></p>
            <p align="left"><span class="texto2">- They&rsquo;re talking about you, Saramma says.  Together all the time. Whispering. This sudden friendship. And he&rsquo;s a senior.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -&nbsp; I&rsquo;m a pre-senior. We&rsquo;re in the play together.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -  You know about him. What if he finds out you had him expelled?<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -  I didn't. You did. He forgives me anyway.</span></p>
            <p align="left">&nbsp;</p>
            <p align="center"><span class="texto2"> </span><span class="titulo1">9</span></p>
            <p align="left"><span class="texto2">We&rsquo;ve been at the boatclub, Adeila and I. It's  Saturday.&nbsp; A fine sky, and the lake&rsquo;s  lime-green before sunset, with boaters still out on the water, trailing their  fingers in its ripples. We&rsquo;ve walked to the cinema, to see Vanessa Redgrave in <em>Camelot</em>.  We&nbsp; stop to buy cokes and chips before we  take our seats.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -  Come and sit with us.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; (It's  Singapore Ramesh. Of course, it's their evening at the movies - I should have  remembered.)<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -  It's OK. We've got a box.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -  No, come on.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; We  follow, sit down.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Five  minutes later, I see Jay in shadow, over-long legs, familiar stoop, curly  hair.&nbsp; He drops into the seat near mine. <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -Hi.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; I  feel his shoulder touch mine, the length of his arm, his knee.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; (  He isn&rsquo;t handsome,&nbsp; Adeila tells me  later. He&rsquo;s dark and his lips are thick. She isn&rsquo;t pretty, Jay says.  Flat-chested; looks like Barbra Streisand.)</span></p>
            <p align="left">&nbsp;</p>
            <p align="center"><span class="texto2"> </span><span class="titulo1">10</span></p>
            <p align="left"><span class="texto2">Monday evening.&nbsp;  I come home from rehearsal to find my parents waiting for me.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -  We&rsquo;ve heard you&rsquo;ve been mixing with the wrong sort of boy. You were with him at  the cinema. (Mother.)<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -  Who?<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -  Don&rsquo;t be rude. You know who. (Father.)<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -  He&rsquo;s my friend. And I'm in the play with him. Can't avoid him.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -Well,  your teachers don&rsquo;t like it. They say it&rsquo;s furtive. (Mother.) <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -&nbsp; And it distracts the other boys. (Father.) <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -  Masud Bhai doesn&rsquo;t like it. </span></p>
            <p align="left">&nbsp;</p>
            <p align="center"><span class="texto2"> </span><span class="titulo1">11</span></p>
            <p align="left"><span class="texto2">I know nothing about boys &lsquo;like that', as they  call them. Once I saw the two Mohans, known to be friends, fight over a ball in  the playground, getting rougher and rougher until one, the taller one, just  seemed to give up and the littler one straddled him, groin on groin, and ground  into him, then knocked his forehead against the other boy's.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -  Don&rsquo;t mind them, they&rsquo;re pals, Fat Ramesh had said. <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -  Do pals fight that way?<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -  Come on man, don't be stupid, I mean pals like&hellip;that.. <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; I  felt as if I&rsquo;d seen something I shouldn&rsquo;t have.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; And  now:<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -  What do we do?&nbsp; Do they think we're..?<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -  Well, we hardly skulk in corners as they say, everyone sees us, so what are we  hiding?<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -  Let&rsquo;s show them we don't care.</span></p>
            <p align="left">&nbsp;</p>
            <p align="center"><span class="texto2"> </span><span class="titulo1">12</span></p>
            <p align="left"><span class="texto2">- You&rsquo;re letting your mother down. Making her  very unhappy. If you don&rsquo;t leave Jay alone he&rsquo;ll be sent away again. So just  cut it out.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Mr  M grabs my arm, nearly twisting it.</span></p>
            <p align="left">&nbsp;</p>
            <p align="center"><span class="texto2"> </span><span class="titulo1">13</span></p>
            <p align="left">In the dressing room we&rsquo;ve been given to share,  I don&rsquo;t talk to him. He doesn&rsquo;t get my silent message. He keeps on  talking.&nbsp; On stage I give the greatest  performance, particularly when Diamond betrays Elviro.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Mr  M tells me I showed too much hairy, muscular thigh. Mrs Pratap's summoned to  drop the hem of my tunic in time for the next performance<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; The  second night, Jay doesn't talk while we dress. When Diamond asks for  forgiveness and Elviro's meant to take my hand, he forgets his lines. <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Silence  takes centre stage for a moment. <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; (I  wish I'd die. Suicide&rsquo;s a sin. I can&rsquo;t jump into the lake or hang myself; I&rsquo;d  be too afraid, so I pray God will just take me away in my sleep.)</p></p>
            <p align="left">&nbsp;</p>
                        <p align="center"><span class="texto2"> </span><span class="titulo1">14</span></p>
                        <p align="left"><span class="texto2">Before the end of term I tell the Rameshes what  happened. <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; The  rainy summer passes. Adeila's gone home to Sikanderabad; I&rsquo;ve driven my parents  to desperation with my lost appetite and my surly moods, and Mr M can&rsquo;t bear to  look at me. My&nbsp; father sets off for  England; he'd said when we came we'd be here just one year, and he&rsquo;s promised  to send for me, if only I&rsquo;ll wait till the next term&rsquo;s over. Even my mother  agrees; she'd never wanted to move away from Karachi and she hates this place, the rain  and the wind and the cold mountain loneliness. So I&rsquo;ll soon be leaving this  strange place, this foreign land, for a faraway country I've never seen, a  country still more foreign and more strange.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;I come back to school.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;Singapore Ramesh tells me:<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -  My uncle understands. He&rsquo;ll wait. <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Then  I know what I must do. <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; I  write to Jay. He writes back. <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; For  weeks we exchange letters, conceal them in books left in appointed corners. We  learn to break rules that were made to be broken.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Sometimes  I have to wait for his replies, two days, three, a week. I write to him and  tear up the messages, swear I'll never write again. And then, as if he knows  what I'm thinking, he writes again. Sometimes his letters are long, at other  they're just notes, a line or two. He signs himself&nbsp;&nbsp; 'Your loving friend.'</span></p>
                        <p align="left">&nbsp;</p>
                        <p align="center"><span class="texto2"> </span><span class="titulo1">15</span></p>
                        <p align="left"><span class="texto2">Sometimes we meet, in secret, in the lab or in  the playing field on the hill. Furtive meetings, as if guilt's what we were  destined for. I'm afraid to be with him now. I feel as if we&rsquo;re on stage again,  rehearsing without a script to read from. When we part, I remember things I  didn't say; it's easier, much easier, to write. <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; I'm  defiant when we talk, but I see him chastened. He has to finish school this  year; he&rsquo;s been loyal to me, but I know what it cost. Me, I 've ceased to care:  I upset everyone. Saramma hasn&rsquo;t talked to me since I confronted her with what  I found out from Mrs Pratap - she was the one who spread stories, complained to  Mr M. Most of my casual friends dropped me when I was declared dangerous  company.&nbsp; <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Singapore  Ramesh keeps faith, and Mrs Pratap.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -  You&rsquo;ve got to get away from here, <em>bachche</em>, she tells me. This place is  too small for you. It&rsquo;ll smash all your dreams.&nbsp;  I&rsquo;m glad you&rsquo;re leaving.</span></p>
            <p align="left">&nbsp;</p>
            <p align="center"><span class="texto2"> </span><span class="titulo1">16</span></p>
            <p align="left"><span class="texto2">Even when Saramma finds one of our notes in the  library I'm not afraid. I'll leave here in a week or two, and Jay a few weeks  after me; it&rsquo;s not worth anyone&rsquo;s while, this time,&nbsp; to make a scene about us.&nbsp; Mr Masud&nbsp;  tells me I can take the last few days off, I needn&rsquo;t bother to come back  before I travel North, on my way to England. Still, when we leave, he&rsquo;s at the  station to say goodbye. He'll be glad to rid himself of&nbsp; me, the wayward, dreamy, stubborn boy I am.  It's November, purple-grey and wet again.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Jay  writes just once. We're in Sikanderabad. My mother finds the letter, and tears  it up.&nbsp; Anyway, I can't reply: he sent no  return address. Our story's over, except when I trace it between the lines of books  I read. </span></p>
            <p align="left">&nbsp;</p>
            <p align="center"><span class="texto2"> </span><span class="titulo1">17</span></p>
            <p align="left"><span class="texto2">There's little left to tell. I reach London in May, a year after that first  exchange with Jay. Mr Masud comes to visit, a month or two after I reach England. We  live on Bayswater Road,  facing Hyde Park. I'm fifteen now, and 6 feet tall; already at high  school, making new friends, buying cheap tickets to see films and plays with a  girl from Venezuela and kissing her in the park. I see Mr M a few times; I call  him Mamunsaheb again. I was a rebel: when I left Arundales he must have marked  me off as his only failure, made excuses for my ways and my defection. But he  never once alludes to my stay in the Nilgiris. It was a slip in time, an  aberration, best forgotten. I am, at the final count, one of the forgiven: a  member of the family, his younger sister&rsquo;s only son.&nbsp; </span></p>            
          <p align="left">&nbsp;</p></td>
          <td><img src="/images/issue_img/spacer.gif" width="1" height="46" border="0" alt=""></td>
        </tr>
        <tr> 
          <td height="103"><img src="/images/issue_img/spacer.gif" width="1" height="103" border="0" alt=""></td>
        </tr>
      </table></td>
  </tr>
</table>
<br>
<?php include("../../foot.php"); ?>
</body>
</html>
