<html>
<head>
<title>menu_issue2</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../estilos.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="281" border="0" cellpadding="0" cellspacing="0" bgcolor="#ffffff">
  <!-- fwtable fwsrc="staff.png" fwbase="issue1.gif" fwstyle="Dreamweaver" fwdocid = "742308039" fwnested="0" -->
  <tr> 
    <td><img src="/images/spacer.gif" width="15" height="1" border="0" alt=""></td>
    <td><img src="/images/spacer.gif" width="173" height="1" border="0" alt=""></td>
    <td><img src="/images/spacer.gif" width="83" height="1" border="0" alt=""></td>
    <td><img src="/images/spacer.gif" width="10" height="1" border="0" alt=""></td>
    <td><img src="/images/spacer.gif" width="1" height="1" border="0" alt=""></td>
  </tr>
  <tr> 
    <td><img name="issue1_r1_c1" src="../ilitq//images/spacer.gif" width="1" height="1" border="0" alt=""></td>
    <td colspan="2"><div align="right">
        <p><a href="/issue2/index_issue2.php"><img name="issue1_r1_c2" src="/images/issue_img/issue2.gif" width="142" height="56" border="0" alt=""></a></p>
        <p><span class="copyright">February 2008</span></p>
      </div></td>
    <td><img name="issue1_r1_c4" src="/images/spacer.gif" width="20" height="10" border="0" alt=""></td>
    <td><img src="/images/issue1_img/spacer.gif" width="1" height="59" border="0" alt=""></td>
  </tr>
  <tr> 
    <td rowspan="5">&nbsp;</td>
    <td colspan="2" valign="bottom"> <div align="right" class="titulo1">Contributors</div></td>
    <td rowspan="5">&nbsp;</td>
    <td><img src="/images/issue1_img/spacer.gif" width="1" height="23" border="0" alt=""></td>
  </tr>
  <tr> 
    <td colspan="2" rowspan="4" valign="top"> <div align="right" class="link1"> 
        <p class="link1"><a href="/issue2/susan_daitch/job.php" class="link1">Susan 
          Daitch</a><br>
          <a href="/issue2/jenny_diski/job.php" class="link1">Jenny 
          Diski</a><br>
          <a href="/issue2/mohamed_el_bisatie/job.php" class="link1">Mohamed 
          El-Bisatie</a><br>
          <a href="/issue2/aamer_hussein/job.php" class="link1">Aamer 
          Hussein</a><br>
          <a href="/issue2/denys_johnson_davies/job.php" class="link1">Denys 
          Johnson-Davies</a><br>
          <a href="/issue2/bret_anthony_johnston/job.php" class="link1">Bret 
          Anthony Johnston</a><br>
          <a href="/issue2/mimi_khalvati/job.php" class="link1">Mimi 
          Khalvati</a><br>
          <a href="/issue2/sara_maitland/job.php" class="link1">Sara 
          Maitland<br>
          </a> <a href="/issue2/dilys_rose/job.php" class="link1">Dilys 
          Rose</a><br>
          <a href="/issue2/iain_sinclair/job.php" class="link1">Iain 
          Sinclair</a></p>
        <p class="link1">&nbsp;</p>
        <p class="link1"><span class="texto2">Founding Editor: <a href="#" class="link1"></a></span><a href="/staff/peter_robertson/bio.php" class="link1">Peter 
          Robertson</a><br>
          <span class="texto2">Art Editor: <a href="#" class="link1"></a></span><a href="/staff/calum_colvin/bio.php" class="link1">Calum 
          Colvin</a><br>
		  <span class="texto2">Consulting Editor: <a href="#" class="link1"></a></span><a href="/issue1/suzanne_jill_levine/bio.php" class="link1">Suzanne Jill Levine</a><br>
          <span class="texto2">Associate Editor: <a href="#" class="link1"></a></span><a href="/staff/neil_langdon_inglis/bio.php" class="link1">Neil 
          Langdon Inglis</a></p>
        </div></td>
    <td><img src="/images/spacer.gif" width="1" height="147" border="0" alt=""></td>
  </tr>
  <tr> 
    <td><img src="/images/spacer.gif" width="1" height="39" border="0" alt=""></td>
  </tr>
  <tr> 
    <td height="79"><img src="/images/spacer.gif" width="1" height="79" border="0" alt=""></td>
  </tr>
  <tr> 
    <td height="103"><img src="/images/spacer.gif" width="1" height="103" border="0" alt=""></td>
  </tr>
</table>
</body>
</html>
