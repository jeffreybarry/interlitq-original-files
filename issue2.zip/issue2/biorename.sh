#!/bin/bash
echo running rename of bio photos
echo "Script executed from ${PWD}"
# get list of directory names
#start with an empty array
DIRECTORIES=()

#for each file in current directory
for FILE in */;do
  #if file is a directory, then add it to the array
   echo $FILE
   author=$(basename "$FILE")
   echo author$author #gets author name
   mv "$author/foto_bio.jpg" "$author.jpg"
done
